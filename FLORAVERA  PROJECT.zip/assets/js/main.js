/* ==========================================================================
   FloraVera - Multipurpose Flower Shop & Floral Services Template
   Main JavaScript (Vanilla ES6, no jQuery)

   Modules
   01. Preloader
   02. Theme (dark / light) with localStorage persistence
   03. Sticky header + scroll progress + back to top
   04. Mobile drawer & accordion
   05. Search overlay
   06. Toast notifications
   07. Mini cart / wishlist / compare counters
   08. Isotope product filtering
   09. Swiper sliders
   10. AOS scroll animations
   11. GLightbox
   12. Custom bouquet builder
   13. Newsletter popup
   14. Recently viewed (localStorage)
   ========================================================================== */

(function () {
  'use strict';

  document.documentElement.classList.remove('no-js');

  const $  = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------
     01. Preloader
  ------------------------------------------------------------------ */
  window.addEventListener('load', () => {
    const loader = $('#fvPreloader');
    if (loader) window.setTimeout(() => loader.classList.add('is-done'), 250);
  });

  /* ------------------------------------------------------------------
     02. Theme toggle
  ------------------------------------------------------------------ */
  const THEME_KEY = 'fv-theme';

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-fv-theme', theme);
    $$('[data-fv-toggle-theme]').forEach((btn) =>
      btn.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode')
    );
  }

  const storedTheme = localStorage.getItem(THEME_KEY);
  applyTheme(storedTheme || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

  $$('[data-fv-toggle-theme]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const next = document.documentElement.getAttribute('data-fv-theme') === 'dark' ? 'light' : 'dark';
      applyTheme(next);
      localStorage.setItem(THEME_KEY, next);
    });
  });

  /* ------------------------------------------------------------------
     03. Sticky header, scroll progress, back to top
  ------------------------------------------------------------------ */
  const header   = $('#fvHeader');
  const progress = $('#fvProgress');
  const toTop    = $('#fvToTop');

  function onScroll() {
    const y = window.scrollY;
    if (header) header.classList.toggle('is-stuck', y > 40);
    if (toTop)  toTop.classList.toggle('is-visible', y > 500);

    if (progress) {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      progress.style.width = max > 0 ? ((y / max) * 100).toFixed(2) + '%' : '0%';
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  if (toTop) {
    toTop.addEventListener('click', () =>
      window.scrollTo({ top: 0, behavior: prefersReduced ? 'auto' : 'smooth' })
    );
  }

  /* ------------------------------------------------------------------
     04. Mobile drawer + accordion
  ------------------------------------------------------------------ */
  const drawer  = $('#fvDrawer');
  const overlay = $('#fvOverlay');

  function closeDrawer() {
    if (drawer) {
      drawer.classList.remove('is-open');
      // Reset all accordion items
      $$('[data-fv-accordion]').forEach((btn) => {
        btn.closest('li').classList.remove('is-open');
        btn.setAttribute('aria-expanded', 'false');
      });
    }
    if (overlay) overlay.classList.remove('is-open');
    document.body.style.removeProperty('overflow');
  }

  $$('[data-fv-open-drawer]').forEach((btn) =>
    btn.addEventListener('click', () => {
      drawer && drawer.classList.add('is-open');
      overlay && overlay.classList.add('is-open');
      document.body.style.overflow = 'hidden';
    })
  );

  $$('[data-fv-close-drawer]').forEach((btn) => btn.addEventListener('click', closeDrawer));
  overlay && overlay.addEventListener('click', closeDrawer);

  // Close drawer on ESC key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && drawer && drawer.classList.contains('is-open')) {
      closeDrawer();
    }
  });

  // Close drawer when clicking on links
  drawer && $$('a', drawer).forEach((link) => {
    link.addEventListener('click', closeDrawer);
  });

  $$('[data-fv-accordion]').forEach((btn) =>
    btn.addEventListener('click', () => {
      const li = btn.closest('li');
      const open = li.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', String(open));
    })
  );

  /* ------------------------------------------------------------------
     05. Search overlay
  ------------------------------------------------------------------ */
  const search = $('#fvSearch');

  function closeSearch() {
    search && search.classList.remove('is-open');
    document.body.style.removeProperty('overflow');
  }

  $$('[data-fv-open-search]').forEach((btn) =>
    btn.addEventListener('click', () => {
      if (!search) return;
      search.classList.add('is-open');
      document.body.style.overflow = 'hidden';
      window.setTimeout(() => $('#fvSearchInput') && $('#fvSearchInput').focus(), 220);
    })
  );

  $$('[data-fv-close-search]').forEach((btn) => btn.addEventListener('click', closeSearch));

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { closeSearch(); closeDrawer(); closePopup(); }
  });

  /* ------------------------------------------------------------------
     06. Toast notifications
  ------------------------------------------------------------------ */
  const toastHost = $('#fvToasts');

  function toast(message, icon = 'bi-check-circle') {
    if (!toastHost) return;
    const el = document.createElement('div');
    el.className = 'fv-toast';
    el.setAttribute('role', 'status');
    el.innerHTML = '<i class="bi ' + icon + '" aria-hidden="true"></i><span>' + message + '</span>';
    toastHost.appendChild(el);
    window.setTimeout(() => {
      el.classList.add('is-leaving');
      el.addEventListener('animationend', () => el.remove());
    }, 3200);
  }

  /* ------------------------------------------------------------------
     07. Cart / wishlist / compare counters
  ------------------------------------------------------------------ */
  const counters = { cart: 2, wishlist: 3, compare: 0 };

  function bump(kind, label, icon) {
    counters[kind] += 1;
    const badge = $('[data-fv-count="' + kind + '"]');
    if (badge) {
      badge.textContent = String(counters[kind]);
      badge.animate(
        [{ transform: 'scale(1)' }, { transform: 'scale(1.45)' }, { transform: 'scale(1)' }],
        { duration: 420, easing: 'ease-out' }
      );
    }
    toast(label, icon);
  }

  $$('[data-fv-add-cart]').forEach((btn) =>
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      bump('cart', (btn.dataset.fvAddCart || 'Item') + ' added to your cart', 'bi-bag-check');
    })
  );

  $$('[data-fv-wishlist]').forEach((btn) =>
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const on = btn.classList.toggle('is-active');
      const icon = $('i', btn);
      if (icon) icon.className = 'bi ' + (on ? 'bi-heart-fill' : 'bi-heart');
      if (on) bump('wishlist', 'Saved to your wishlist', 'bi-heart-fill');
      else toast('Removed from wishlist', 'bi-heart');
    })
  );

  $$('[data-fv-compare]').forEach((btn) =>
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      bump('compare', 'Added to comparison', 'bi-arrow-left-right');
    })
  );

  /* ------------------------------------------------------------------
     07b. Blog pagination  [data-fv-blog-grid] + [data-fv-pagination]
  ------------------------------------------------------------------ */
  $$('[data-fv-blog-grid]').forEach((grid) => {
    const pager = grid.parentElement
      ? grid.parentElement.querySelector('[data-fv-pagination]')
      : null;
    if (!pager) return;
    const items = $$('[data-fv-page]', grid);
    const links = $$('[data-fv-page-link]', pager);
    const pageCount = links.length || 1;
    let page = 1;

    const show = (n) => {
      page = n;
      items.forEach((el) => {
        el.hidden = Number(el.dataset.fvPage || 1) !== n;
      });
      links.forEach((b) => {
        const on = Number(b.dataset.fvPageLink) === n;
        b.classList.toggle('is-current', on);
        if (on) b.setAttribute('aria-current', 'page');
        else b.removeAttribute('aria-current');
      });
    };

    links.forEach((b) =>
      b.addEventListener('click', () => {
        show(Number(b.dataset.fvPageLink) || 1);
        grid.scrollIntoView({ behavior: prefersReduced ? 'auto' : 'smooth', block: 'start' });
      })
    );
    const next = $('[data-fv-page-next]', pager);
    if (next)
      next.addEventListener('click', () => {
        show(page >= pageCount ? 1 : page + 1);
        grid.scrollIntoView({ behavior: prefersReduced ? 'auto' : 'smooth', block: 'start' });
      });

    show(1);
  });

  /* ------------------------------------------------------------------
     08. Isotope product filtering
  ------------------------------------------------------------------ */
  const grids = $$('#fvProductGrid, #fvShopGrid');

  grids.forEach((grid) => {
    if (typeof Isotope === 'undefined') return;

    /** Read a numeric price out of a product card. */
    const priceOf = (item) => {
      const el = item.querySelector('.fv-product__price');
      const m = el && el.textContent.replace(/<del[\s\S]*/, '').match(/([\d.,]+)/);
      return m ? parseFloat(m[1].replace(/,/g, '')) : 0;
    };
    const nameOf = (item) => {
      const el = item.querySelector('.fv-product__title');
      return el ? el.textContent.trim().toLowerCase() : '';
    };

    const state = { cat: '*', max: Infinity, page: 1 };
    const pager = grid.parentElement
      ? grid.parentElement.querySelector('[data-fv-pagination]')
      : null;

    imagesLoadedThen(grid, () => {
      const iso = new Isotope(grid, {
        itemSelector: '.fv-grid-item',
        layoutMode: 'fitRows',
        transitionDuration: prefersReduced ? 0 : '0.5s',
        getSortData: { price: priceOf, name: nameOf }
      });

      const countOut = $('[data-fv-visible-count]');
      const pageLinks = pager ? $$('[data-fv-page-link]', pager) : [];
      const pageCount = pageLinks.length || 1;

      const syncPager = () => {
        pageLinks.forEach((b) => {
          const on = Number(b.dataset.fvPageLink) === state.page;
          b.classList.toggle('is-current', on);
          if (on) b.setAttribute('aria-current', 'page');
          else b.removeAttribute('aria-current');
        });
      };

      const apply = () => {
        iso.arrange({
          filter: (itemElem) => {
            const el = itemElem;
            const catOk = state.cat === '*' || el.matches(state.cat);
            const priceOk = priceOf(el) <= state.max;
            const pageOk = !pager || Number(el.dataset.fvPage || 1) === state.page;
            return catOk && priceOk && pageOk;
          }
        });
        syncPager();
        if (countOut) countOut.textContent = String(iso.filteredItems.length);
      };

      /* Pagination */
      pageLinks.forEach((btn) =>
        btn.addEventListener('click', () => {
          state.page = Number(btn.dataset.fvPageLink) || 1;
          apply();
          grid.scrollIntoView({ behavior: prefersReduced ? 'auto' : 'smooth', block: 'start' });
        })
      );
      if (pager) {
        const next = $('[data-fv-page-next]', pager);
        if (next)
          next.addEventListener('click', () => {
            state.page = state.page >= pageCount ? 1 : state.page + 1;
            apply();
            grid.scrollIntoView({ behavior: prefersReduced ? 'auto' : 'smooth', block: 'start' });
          });
      }

      /* Filter pills */
      $$('[data-fv-filter]').forEach((btn) =>
        btn.addEventListener('click', () => {
          $$('[data-fv-filter]').forEach((b) => b.classList.remove('is-active'));
          btn.classList.add('is-active');
          state.cat = btn.dataset.fvFilter || '*';
          state.page = 1;
          syncCatLinks();
          apply();
        })
      );


      /* Sidebar category links */
      const catLinks = $$('[data-fv-cat-link]');
      const syncCatLinks = () => {
        catLinks.forEach((a) => a.classList.toggle('is-active', a.dataset.fvCatLink === state.cat));
        $$('[data-fv-filter]').forEach((b) =>
          b.classList.toggle('is-active', b.dataset.fvFilter === state.cat)
        );
      };
      catLinks.forEach((a) =>
        a.addEventListener('click', (e) => {
          e.preventDefault();
          state.cat = a.dataset.fvCatLink || '*';
          state.page = 1;
          syncCatLinks();
          apply();
        })
      );

      /* Price range */
      const range = $('#fvPrice');
      const priceOut = $('[data-fv-price-out]');
      if (range) {
        const onRange = () => {
          state.max = Number(range.value);
          state.page = 1;
          if (priceOut) priceOut.textContent = '$' + range.value;
          apply();
        };
        range.addEventListener('input', onRange);
        onRange();
      }

      /* Sorting */
      const sort = $('[data-fv-sort]');
      if (sort) {
        sort.addEventListener('change', () => {
          const v = sort.value;
          if (v === 'asc') iso.arrange({ sortBy: 'price', sortAscending: true });
          else if (v === 'desc') iso.arrange({ sortBy: 'price', sortAscending: false });
          else if (v === 'name') iso.arrange({ sortBy: 'name', sortAscending: true });
          else iso.arrange({ sortBy: 'original-order' });
        });
      }

      /* Checkbox filter groups simply re-layout the grid (demo data) */
      $$('.fv-sidebar .fv-check input').forEach((cb) => cb.addEventListener('change', apply));

      apply();
      window.addEventListener('resize', () => iso.layout());
    });
  });

  /** Minimal images-loaded helper so we do not ship another plugin. */
  function imagesLoadedThen(scope, cb) {
    const imgs = $$('img', scope).filter((img) => !img.complete);
    if (!imgs.length) return cb();
    let left = imgs.length;
    const done = () => { if (--left <= 0) cb(); };
    imgs.forEach((img) => {
      img.addEventListener('load', done, { once: true });
      img.addEventListener('error', done, { once: true });
    });
  }

  /* ------------------------------------------------------------------
     09. Swiper sliders
  ------------------------------------------------------------------ */
  if (typeof Swiper !== 'undefined') {
    if ($('#fvCollectionSlider')) {
      new Swiper('#fvCollectionSlider', {
        slidesPerView: 1.15,
        spaceBetween: 22,
        grabCursor: true,
        navigation: { nextEl: '#fvCollectionNext', prevEl: '#fvCollectionPrev' },
        breakpoints: { 576: { slidesPerView: 2.1 }, 992: { slidesPerView: 3 }, 1200: { slidesPerView: 4 } }
      });
    }

    if ($('#fvReviewSlider')) {
      new Swiper('#fvReviewSlider', {
        slidesPerView: 1,
        spaceBetween: 24,
        autoHeight: false,
        pagination: { el: '#fvReviewPager', clickable: true },
        autoplay: prefersReduced ? false : { delay: 5200, disableOnInteraction: false },
        breakpoints: { 768: { slidesPerView: 2 }, 1200: { slidesPerView: 3 } }
      });
    }
  }

  /* ------------------------------------------------------------------
     10. AOS
  ------------------------------------------------------------------ */
  if (typeof AOS !== 'undefined') {
    AOS.init({ duration: 850, easing: 'ease-out-cubic', once: true, offset: 90, disable: prefersReduced });
  }

  /* ------------------------------------------------------------------
     11. GLightbox
  ------------------------------------------------------------------ */
  if (typeof GLightbox !== 'undefined') {
    GLightbox({ selector: '.fv-glightbox', touchNavigation: true, loop: true });
  }

  /* ------------------------------------------------------------------
     12. Custom bouquet builder
  ------------------------------------------------------------------ */
  const builder = $('#fvBuilder');

  if (builder) {
    const priceEl = $('#fvBuilderTotal');

    const total = () =>
      $$('[data-fv-price]', builder)
        .filter((chip) => chip.classList.contains('is-active'))
        .reduce((sum, chip) => sum + parseFloat(chip.dataset.fvPrice), 0);

    function render() {
      if (priceEl) priceEl.textContent = '$' + total().toFixed(2);
    }

    $$('[data-fv-price]', builder).forEach((chip) =>
      chip.addEventListener('click', () => {
        $$('[data-fv-price]', chip.parentElement).forEach((c) => {
          c.classList.remove('is-active');
          c.setAttribute('aria-pressed', 'false');
        });
        chip.classList.add('is-active');
        chip.setAttribute('aria-pressed', 'true');
        render();
      })
    );

    render();
  }

  /* ------------------------------------------------------------------
     13. Newsletter popup (shown once per session)
  ------------------------------------------------------------------ */
  const popup = $('#fvPopup');

  function closePopup() {
    popup && popup.classList.remove('is-open');
  }

  if (popup && !sessionStorage.getItem('fv-popup-seen')) {
    window.setTimeout(() => {
      popup.classList.add('is-open');
      sessionStorage.setItem('fv-popup-seen', '1');
    }, 6500);
  }

  $$('[data-fv-close-popup]').forEach((btn) => btn.addEventListener('click', closePopup));
  popup && popup.addEventListener('click', (e) => { if (e.target === popup) closePopup(); });

  /* ------------------------------------------------------------------
     14. Recently viewed products (localStorage)
  ------------------------------------------------------------------ */
  const VIEWED_KEY = 'fv-recently-viewed';
  const viewedHost = $('#fvRecentlyViewed');

  function readViewed() {
    try { return JSON.parse(localStorage.getItem(VIEWED_KEY)) || []; }
    catch (err) { return []; }
  }

  function pushViewed(item) {
    const list = readViewed().filter((entry) => entry.title !== item.title);
    list.unshift(item);
    localStorage.setItem(VIEWED_KEY, JSON.stringify(list.slice(0, 4)));
    renderViewed();
  }

  function renderViewed() {
    if (!viewedHost) return;
    const list = readViewed();
    const wrap = viewedHost.closest('[data-fv-recent-wrap]');
    if (wrap) wrap.hidden = list.length === 0;

    viewedHost.innerHTML = list
      .map(
        (item) =>
          '<li class="d-flex align-items-center gap-3">' +
          '<img src="' + item.image + '" alt="" width="64" height="64" loading="lazy" class="rounded-3" style="object-fit:cover">' +
          '<span><strong class="d-block">' + item.title + '</strong>' +
          '<small>' + item.price + '</small></span></li>'
      )
      .join('');
  }

  $$('[data-fv-quickview]').forEach((btn) =>
    btn.addEventListener('click', () => {
      const card = btn.closest('[data-fv-product]');
      if (!card) return;
      pushViewed({
        title: card.dataset.fvTitle,
        price: card.dataset.fvPriceLabel,
        image: card.dataset.fvImage
      });

      const modal = $('#fvQuickView');
      if (!modal) return;
      $('#fvQuickViewTitle').textContent = card.dataset.fvTitle;
      $('#fvQuickViewPrice').textContent = card.dataset.fvPriceLabel;
      $('#fvQuickViewCat').textContent = card.dataset.fvCat;
      $('#fvQuickViewImage').src = card.dataset.fvImage;
      $('#fvQuickViewImage').alt = card.dataset.fvTitle;

      if (window.bootstrap) bootstrap.Modal.getOrCreateInstance(modal).show();
    })
  );

  renderViewed();

  /* ------------------------------------------------------------------
     Demo form handlers - replace with your own backend endpoint.
  ------------------------------------------------------------------ */
  $$('[data-fv-demo-form]').forEach((form) =>
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      form.reset();
      toast(form.dataset.fvDemoForm || 'Thank you, we will be in touch.', 'bi-envelope-check');
      closePopup();
    })
  );

  /* ------------------------------------------------------------------
     15. Quantity steppers  [data-fv-qty]
  ------------------------------------------------------------------ */
  $$('[data-fv-qty]').forEach((box) => {
    const input = box.querySelector('input');
    box.addEventListener('click', (e) => {
      const step = e.target.closest('[data-fv-step]');
      if (!step || !input) return;
      const next = (parseInt(input.value, 10) || 1) + Number(step.dataset.fvStep);
      input.value = Math.max(1, Math.min(99, next));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    });
  });

  /* ------------------------------------------------------------------
     16. Product gallery thumbnails  [data-fv-gallery]
  ------------------------------------------------------------------ */
  $$('[data-fv-gallery]').forEach((gallery) => {
    const main = gallery.querySelector('[data-fv-gallery-main]');
    const thumbs = $$('[data-fv-gallery-thumb]', gallery);

    thumbs.forEach((thumb) =>
      thumb.addEventListener('click', () => {
        const img = thumb.querySelector('img');
        if (!main || !img) return;
        main.src = img.src;
        main.alt = img.alt;
        thumbs.forEach((t) => t.classList.remove('is-active'));
        thumb.classList.add('is-active');
      })
    );
  });

  /* ------------------------------------------------------------------
     17. Tabs  [data-fv-tab="panelId"]
  ------------------------------------------------------------------ */
  $$('[data-fv-tabs]').forEach((group) => {
    const buttons = $$('[data-fv-tab]', group);

    buttons.forEach((btn) =>
      btn.addEventListener('click', () => {
        buttons.forEach((b) => {
          b.classList.toggle('is-active', b === btn);
          b.setAttribute('aria-selected', String(b === btn));
        });
        buttons.forEach((b) => {
          const panel = document.getElementById(b.dataset.fvTab);
          if (panel) panel.classList.toggle('is-active', b === btn);
        });
      })
    );
  });

  /* ------------------------------------------------------------------
     18. FAQ accordion  [data-fv-faq]
  ------------------------------------------------------------------ */
  $$('[data-fv-faq]').forEach((list) => {
    $$('.fv-faq__q', list).forEach((q) =>
      q.addEventListener('click', () => {
        const item = q.closest('.fv-faq__item');
        const open = item.classList.contains('is-open');
        if (!list.hasAttribute('data-fv-faq-multi')) {
          $$('.fv-faq__item', list).forEach((i) => {
            i.classList.remove('is-open');
            i.querySelector('.fv-faq__q').setAttribute('aria-expanded', 'false');
          });
        }
        item.classList.toggle('is-open', !open);
        q.setAttribute('aria-expanded', String(!open));
      })
    );
  });

  /* ------------------------------------------------------------------
     19. Shop toolbar: grid / list view toggle
  ------------------------------------------------------------------ */
  $$('[data-fv-view]').forEach((btn) =>
    btn.addEventListener('click', () => {
      const grid = $('#fvShopGrid');
      if (!grid) return;
      $$('[data-fv-view]').forEach((b) => b.classList.toggle('is-active', b === btn));
      grid.classList.toggle('fv-shop-list', btn.dataset.fvView === 'list');
    })
  );

  /* ------------------------------------------------------------------
     20. Colour swatch selection (shop sidebar + product options)
  ------------------------------------------------------------------ */
  $$('[data-fv-swatches]').forEach((group) =>
    $$('button', group).forEach((btn) =>
      btn.addEventListener('click', () => {
        $$('button', group).forEach((b) => b.classList.toggle('is-active', b === btn));
      })
    )
  );

  /* ------------------------------------------------------------------
     21. Admin dashboard sidebar toggle
  ------------------------------------------------------------------ */
  const aside = $('#fvAside');
  if (aside) {
    $$('[data-fv-toggle-aside]').forEach((btn) =>
      btn.addEventListener('click', () => aside.classList.toggle('is-open'))
    );
    document.addEventListener('click', (e) => {
      if (window.innerWidth > 991 || !aside.classList.contains('is-open')) return;
      if (!e.target.closest('#fvAside') && !e.target.closest('[data-fv-toggle-aside]')) {
        aside.classList.remove('is-open');
      }
    });
  }

  /* ------------------------------------------------------------------
     22. Animated counters  [data-fv-countup="1240"]
  ------------------------------------------------------------------ */
  const countUpEls = $$('[data-fv-countup]');
  if (countUpEls.length && 'IntersectionObserver' in window) {
    const io = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const el = entry.target;
          const target = Number(el.dataset.fvCountup) || 0;
          const prefix = el.dataset.fvPrefix || '';
          const suffix = el.dataset.fvSuffix || '';
          const start = performance.now();
          const dur = 1400;

          const tick = (now) => {
            const p = Math.min((now - start) / dur, 1);
            const eased = 1 - Math.pow(1 - p, 3);
            el.textContent = prefix + Math.round(target * eased).toLocaleString() + suffix;
            if (p < 1) requestAnimationFrame(tick);
          };
          requestAnimationFrame(tick);
          obs.unobserve(el);
        });
      },
      { threshold: 0.4 }
    );
    countUpEls.forEach((el) => io.observe(el));
  }

  /* ------------------------------------------------------------------
     23. Cart totals  [data-fv-cart]
     Quantity steppers and manual input update the line total, the
     subtotal and the grand total live.
  ------------------------------------------------------------------ */
  $$('[data-fv-cart]').forEach((table) => {
    const money = (n) => '$' + n.toFixed(2);
    const shippingEl = $('[data-fv-shipping]');
    const subtotalEl = $('[data-fv-subtotal]');
    const totalEl = $('[data-fv-grandtotal]');

    const recalc = () => {
      let subtotal = 0;
      $$('tbody tr', table).forEach((row) => {
        const unit = parseFloat(row.querySelector('[data-fv-unit-price]')?.dataset.fvUnitPrice || '0');
        const qty = Math.max(1, parseInt(row.querySelector('[data-fv-qty] input')?.value, 10) || 1);
        const line = unit * qty;
        subtotal += line;
        const out = row.querySelector('[data-fv-line-total]');
        if (out) out.textContent = money(line);
      });

      const rows = $$('tbody tr', table).length;
      const shipping = rows ? Number(shippingEl?.dataset.fvShipping || 0) : 0;
      if (shippingEl) shippingEl.textContent = shipping ? money(shipping) : 'Free';
      if (subtotalEl) subtotalEl.textContent = money(subtotal);
      if (totalEl) totalEl.textContent = money(subtotal + shipping);
    };

    table.addEventListener('input', (e) => {
      if (e.target.closest('[data-fv-qty]')) recalc();
    });
    table.addEventListener('change', (e) => {
      if (e.target.closest('[data-fv-qty]')) recalc();
    });
    table.addEventListener('click', (e) => {
      if (e.target.closest('[data-fv-step]')) setTimeout(recalc, 0);
      const rm = e.target.closest('[data-fv-remove-line]');
      if (rm) {
        rm.closest('tr').remove();
        recalc();
        toast('Removed from your bag', 'bi-bag-x');
      }
    });

    recalc();
  });

  /* ------------------------------------------------------------------
     24. Demo sign-in  [data-fv-login] -> admin dashboard
  ------------------------------------------------------------------ */
  $$('[data-fv-login]').forEach((form) =>
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      toast('Signed in — opening your dashboard', 'bi-person-check');
      const url = form.dataset.fvRedirect || 'dashboard/index.html';
      try { localStorage.setItem('fv-signed-in', '1'); } catch (err) {}
      setTimeout(() => { window.location.href = url; }, 700);
    })
  );

  /* ------------------------------------------------------------------
     25. RTL / Arabic direction toggle  [data-fv-toggle-dir]
  ------------------------------------------------------------------ */
  (function directionToggle() {
    const html = document.documentElement;
    const KEY = 'fv-dir';

    const setDir = (dir, persist) => {
      html.setAttribute('dir', dir);
      html.setAttribute('lang', dir === 'rtl' ? 'ar' : 'en');
      html.classList.toggle('fv-rtl', dir === 'rtl');
      $$('[data-fv-dir-label]').forEach((el) => { el.textContent = dir === 'rtl' ? 'EN' : 'ع'; });
      $$('[data-fv-dir-icon]').forEach((el) => {
        el.classList.toggle('bi-text-right', dir !== 'rtl');
        el.classList.toggle('bi-text-left', dir === 'rtl');
      });
      $$('[data-fv-toggle-dir]').forEach((el) => {
        el.setAttribute('aria-pressed', dir === 'rtl' ? 'true' : 'false');
        el.setAttribute('title', dir === 'rtl' ? 'Switch to left-to-right (English)' : 'Switch to right-to-left (العربية)');
      });
      if (persist) { try { localStorage.setItem(KEY, dir); } catch (e) {} }
      document.querySelectorAll('.swiper').forEach((el) => {
        if (el.swiper) { el.swiper.changeLanguageDirection?.(dir); el.swiper.update(); }
      });
    };

    let saved = null;
    try { saved = localStorage.getItem(KEY); } catch (e) {}
    setDir(saved === 'rtl' ? 'rtl' : 'ltr', false);

    $$('[data-fv-toggle-dir]').forEach((btn) =>
      btn.addEventListener('click', () => {
        const next = html.getAttribute('dir') === 'rtl' ? 'ltr' : 'rtl';
        setDir(next, true);
        toast(next === 'rtl' ? 'تم تفعيل الوضع العربي (RTL)' : 'Left-to-right layout restored', 'bi-translate');
      })
    );
  })();

  /* ------------------------------------------------------------------
     26. Coming soon countdown  [data-fv-countdown="ISO date"]
  ------------------------------------------------------------------ */
  $$('[data-fv-countdown]').forEach((box) => {
    const target = new Date(box.dataset.fvCountdown).getTime();
    const out = (k) => box.querySelector('[data-fv-cd="' + k + '"]');
    const pad = (n) => String(Math.max(0, n)).padStart(2, '0');

    const tick = () => {
      const diff = Math.max(0, target - Date.now());
      const s = Math.floor(diff / 1000);
      if (out('days')) out('days').textContent = pad(Math.floor(s / 86400));
      if (out('hours')) out('hours').textContent = pad(Math.floor((s % 86400) / 3600));
      if (out('minutes')) out('minutes').textContent = pad(Math.floor((s % 3600) / 60));
      if (out('seconds')) out('seconds').textContent = pad(s % 60);
    };
    tick();
    window.setInterval(tick, 1000);
  });
})();
