# FloraVera — Multipurpose Flower Shop & Floral Services HTML Template

Premium, 100% original HTML5 / Bootstrap 5.3 / SCSS template for flower shops,
florists, wedding and event florals, gift delivery and bouquet businesses.

This package contains **Home Page 1** built to full production finish, together
with the complete design system, component library and JavaScript layer that the
remaining pages are built on.

---

## What's inside

```
/assets
  /css      main.css, main.min.css      (compiled — do not edit by hand)
  /scss     _variables, _mixins, _base, _components,
            _header, _sections, _dark, _rtl, main.scss
  /js       main.js                     (vanilla ES6, no jQuery)
  /images   19 original photographs + favicon.svg
/documentation
  index.html                            (full developer documentation)
index.html                              (Home Page 1)
README.md
```

## Build the CSS

The stylesheet is authored in SCSS and compiled with Dart Sass.

```bash
npm install -g sass

# development (expanded, watch)
sass --watch assets/scss/main.scss assets/css/main.css --style=expanded

# production (minified)
sass assets/scss/main.scss assets/css/main.min.css --style=compressed
```

Then swap the stylesheet link in `index.html` to `assets/css/main.min.css`
before going live.

## Re-skin in one file

Every colour, font, radius, shadow and spacing value is a token in
`assets/scss/_variables.scss`, exposed as a CSS custom property in `_base.scss`.
Change the six brand values at the top of `_variables.scss` and the whole
template — light mode, dark mode, gradients and shadows — follows.

```scss
$fv-plum:  #6B2D4F;  // primary
$fv-rose:  #D9A5B3;  // accent
$fv-blush: #FBF6F7;  // page background
$fv-ink:   #2B1F26;  // text
```

## Dark mode

Driven by `data-fv-theme="dark"` on `<html>` and persisted in `localStorage`
under `fv-theme`. It respects `prefers-color-scheme` on a first visit. The
header toggle is any element carrying `data-fv-toggle-theme`.

## RTL

The layout uses CSS logical properties throughout, so switching direction is a
one-attribute change:

```html
<html lang="ar" dir="rtl">
```

`_rtl.scss` corrects the handful of genuinely direction-bound pieces (marquee,
directional icons, drawer slide-in, gradient direction).

## JavaScript modules

`assets/js/main.js` is plain ES6 in a single IIFE, commented and numbered:
preloader, theme, sticky header + scroll progress + back to top, mobile drawer,
search overlay, toasts, cart/wishlist/compare counters, Isotope filtering,
Swiper sliders, AOS, GLightbox, bouquet builder, newsletter popup, recently
viewed (localStorage) and quick view.

Forms carrying `data-fv-demo-form="..."` are demo handlers — point them at your
own endpoint before launch.

## Third-party libraries

Bootstrap 5.3.3, Bootstrap Icons 1.11.3, Swiper 11, AOS 2.3.4, GLightbox and
Isotope are loaded from jsDelivr CDN in `index.html`. To ship them locally,
download each into `/assets/plugins/` and update the `<link>` / `<script>`
tags — no other change is required.

## Images

All 19 photographs were generated for this template and are licence-free for
resale within it. Swap any file in `/assets/images/` keeping the same filename
and every reference updates. All media wrappers use fixed `aspect-ratio` with
`object-fit: cover`, so replacement images never stretch.

## Accessibility & SEO

Semantic landmarks, a skip link, visible focus rings, ARIA labels on every icon
control, `prefers-reduced-motion` support, one `<h1>` per page, descriptive alt
text, Open Graph and Twitter cards, canonical tag and `Florist` JSON-LD.

## Browser support

Chrome, Edge, Firefox, Safari (latest two versions), iOS Safari and Chrome
Android.

---

© 2026 FloraVera template. Support: hello@floravera.com
